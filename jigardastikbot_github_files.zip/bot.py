import asyncio
import logging
import os
import tempfile
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, FSInputFile
from aiogram.enums import ContentType
from PIL import Image

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is not set")

bot = Bot(TOKEN)
dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "👋 Salom! Men sticker botman.\n\n"
        "🖼 Rasm yuboring — stickerga aylantiraman.\n"
        "/help — yordam"
    )

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer("🖼 Oddiy rasm yuboring — men uni stickerga aylantiraman.")

@dp.message(F.content_type == ContentType.PHOTO)
async def photo_to_sticker(message: Message):
    tmp = Path(tempfile.mkdtemp(prefix="sticker_"))
    src = tmp / "input.jpg"
    out = tmp / "sticker.webp"
    try:
        await bot.download(message.photo[-1], destination=src)
        img = Image.open(src).convert("RGBA")
        img.thumbnail((512, 512), Image.Resampling.LANCZOS)
        canvas = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
        canvas.alpha_composite(img, ((512-img.width)//2, (512-img.height)//2))
        canvas.save(out, "WEBP", lossless=True, quality=100)
        await message.answer_sticker(FSInputFile(out))
    except Exception:
        logging.exception("sticker conversion failed")
        await message.answer("❌ Xatolik yuz berdi.")
    finally:
        for p in tmp.glob("*"):
            p.unlink(missing_ok=True)
        tmp.rmdir()

@dp.message(F.content_type == ContentType.STICKER)
async def sticker_info(message: Message):
    await message.answer(f"🧩 Emoji: {message.sticker.emoji or '—'}")

async def main():
    logging.basicConfig(level=logging.INFO)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
