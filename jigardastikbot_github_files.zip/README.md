# jigardastikbot

Telegram sticker bot. Rasm -> sticker.

Set BOT_TOKEN as an environment variable. Never publish the real token.
